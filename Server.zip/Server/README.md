# _1st_API
REST API for a laboratory equipment monitoring system
